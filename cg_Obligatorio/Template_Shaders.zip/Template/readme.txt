Framework de Computacion Grafica para C.
=============================================
Version:
	* 3.0

Requerimientos:
	* Ambiente de desarrollo de C.
	* libSDL (www.libsdl.org)

Usuarios de MS Windows pueden utilizar esta carpeta como esqueleto de proyecto.

El archivo Makefile.win32 controla el proceso de compilacion. Para agregar nuevos archivos con codigo fuente, simplemente se crean los archivos .h y .c necesarios en la raiz y se los agrega a la lista de objetos en el archivo Makefile.win32.

Se proveen los atajos: build.bat, clean.bat y run.bat para compilar, limpiar y ejecutar el proyecto, respectivamente.
